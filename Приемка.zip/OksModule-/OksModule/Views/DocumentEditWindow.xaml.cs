﻿using OksModule.Commands;
using OksModule.Models;
using OksModule.Services;
using OksModule.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using System.Windows.Input;


namespace OksModule.Views
{
    /// <summary>
    /// Логика взаимодействия для DocumentEditWindow.xaml
    /// </summary>
    public partial class DocumentEditWindow : Window
    {
      
        
            public Document Document { get; private set; }

            public DocumentEditWindow(Document documentToEdit)
            {
                InitializeComponent();
                Document = documentToEdit; // Сохраняем переданный документ
                DataContext = new DocumentEditViewModel(Document, this);
            }
       
    }



    
}


