﻿using OksModule.Commands;
using OksModule.Models;
using OksModule.Services;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace OksModule.ViewModels
{
    public class DocumentEditViewModel : ViewModelBase
    {
        private readonly Window _window;
        public Document Document { get; set; }

        public ObservableCollection<string> DocumentTypes { get; } = new ObservableCollection<string>
        {
            "Технические условия",
            "Расчет стоимости",
            "Проектная документация",
            "Запрос на изыскания"
        };

        public ObservableCollection<Department> Departments { get; } = new ObservableCollection<Department>();

        public ICommand SaveCommand { get; }

    public DocumentEditViewModel(Document document, Window window)
        {
            Document = document;
            _window = window;
            if (string.IsNullOrEmpty(Document.DocumentType) && DocumentTypes.Count > 0)
            {
                Document.DocumentType = DocumentTypes[0]; // Установка первого значения по умолчанию
            }

            SaveCommand = new RelayCommand(
                execute: _ => SaveDocument(), // Явное указание параметра
                canExecute: _ => true);       // Всегда доступна для сохранения
            
            LoadDepartmentsAsync();
        }

        private async void LoadDepartmentsAsync()
        {
            try
            {
                var dbService = new DatabaseService();
                var departments = await dbService.GetAllDepartmentsAsync();

                Departments.Clear();
                foreach (var dep in departments)
                {
                    Departments.Add(dep);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки отделов: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void SaveDocument()
        {
            _window.DialogResult = true;
            _window.Close();
        }
    }
}

