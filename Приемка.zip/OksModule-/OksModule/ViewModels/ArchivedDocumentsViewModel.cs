﻿using OksModule.Commands;
using OksModule.Models;
using OksModule.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace OksModule.ViewModels
{
    public class ArchivedDocumentsViewModel : ViewModelBase
    {
        private readonly DatabaseService _dbService;
        private Document _selectedDocument;

        public ObservableCollection<ArchivedDocument> ArchivedDocuments { get; }
        public Document SelectedDocument
        {
            get => _selectedDocument;
            set
            {
                _selectedDocument = value;
                OnPropertyChanged();
                (RestoreCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }
    
     public string StatusMessage { get; set; }

        public ICommand RefreshCommand { get; }
        public ICommand RestoreCommand { get; }

        public ArchivedDocumentsViewModel()
        {
            _dbService = new DatabaseService();
            ArchivedDocuments = new ObservableCollection<ArchivedDocument>();

            RefreshCommand = new RelayCommand(_ => LoadArchivedDocuments());
          
            RestoreCommand = new RelayCommand(
                execute: _ => RestoreDocument(),
                canExecute: _ => CanRestoreDocument()
            );

            LoadArchivedDocuments();
        }

        private bool CanRestoreDocument() => SelectedDocument != null;

        private void RestoreDocument()
        {
            try
            {
                var result = MessageBox.Show(
                    $"Восстановить документ '{SelectedDocument.Title}'?",
                    "Подтверждение восстановления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    _dbService.RestoreDocument(SelectedDocument.DocumentId);
                    StatusMessage = $"Документ ID {SelectedDocument.DocumentId} восстановлен";
                    LoadArchivedDocuments();
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка восстановления: {ex.Message}";
                MessageBox.Show($"Ошибка при восстановлении документа: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadArchivedDocuments()
        {
            try
            {
                ArchivedDocuments.Clear();
                var docs = _dbService.GetArchivedDocuments();
                foreach (var doc in docs)
                {
                    ArchivedDocuments.Add(doc);
                }
                StatusMessage = $"Загружено архивных документов: {ArchivedDocuments.Count}";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки архива: {ex.Message}";
            }
        }
    }
}
