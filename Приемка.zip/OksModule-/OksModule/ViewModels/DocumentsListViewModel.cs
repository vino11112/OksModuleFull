﻿using OksModule.Commands;
using OksModule.Models;
using OksModule.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.Design;
using System.Windows;
using System.Windows.Input;
using OksModule.Views;

namespace OksModule.ViewModels
{
    public class DocumentsListViewModel : ViewModelBase
    {
        private readonly DatabaseService _dbService = new DatabaseService();
        private readonly CommunicationService _commService = new CommunicationService();

        private Document _selectedDocument;
        public Document SelectedDocument
        {
            get => _selectedDocument;
            set
            {
                if (_selectedDocument != value)
                {
                    _selectedDocument = value;
                    OnPropertyChanged();
                    RefreshCommands();
                }
            }
        }
        private ObservableCollection<Document> _archivedDocuments;
        public ObservableCollection<Document> ArchivedDocuments
        {
            get => _archivedDocuments;
            set
            {
                _archivedDocuments = value;
                OnPropertyChanged();
            }
        }
        private string _statusMessage;
        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                OnPropertyChanged();
            }
        }
        private Document _selectedArchivedDocument;
        public Document SelectedArchivedDocument
        {
            get => _selectedArchivedDocument;
            set
            {
                _selectedArchivedDocument = value;
                OnPropertyChanged();
                (RestoreCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }


        public ObservableCollection<Document> Documents { get; private set; }

        public ICommand RefreshCommand { get; }
        public ICommand ArchiveCommand { get; }

        public ICommand AddCommand { get; }
        public ICommand EditCommand { get; }
        public ICommand ApproveCommand { get; }
        public ICommand SendCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand RestoreCommand { get; }

        public DocumentsListViewModel()
        {
            _dbService = new DatabaseService();
            _commService = new CommunicationService();
            Documents = new ObservableCollection<Document>();
            ArchivedDocuments = new ObservableCollection<Document>();

            // Инициализация команд
            ArchiveCommand = new RelayCommand(_ => ArchiveDocument(), _ => CanArchiveDocument());
            RestoreCommand = new RelayCommand(
                execute: _ => RestoreDocument(),
                canExecute: _ => CanRestoreDocument()
            );
            RefreshCommand = new RelayCommand(_ => LoadDocuments());
            AddCommand = new RelayCommand(_ => AddDocument());
            EditCommand = new RelayCommand(_ => EditDocument(), _ => CanEditDocument());
            ApproveCommand = new RelayCommand(_ => ApproveDocument(), _ => CanApproveDocument());
            SendCommand = new RelayCommand(_ => SendDocument(), _ => CanSendDocument());
            DeleteCommand = new RelayCommand(_ => DeleteDocument(), _ => CanDeleteDocument());

            LoadDocuments();
            LoadArchivedDocuments();
        }
        private bool CanRestoreDocument()
        {
            return SelectedArchivedDocument != null;
        }

        private void RestoreDocument()
        {
            try
            {
                var result = MessageBox.Show(
                    $"Восстановить документ '{SelectedArchivedDocument.Title}'?",
                    "Подтверждение восстановления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    _dbService.RestoreDocument(SelectedArchivedDocument.DocumentId);
                    StatusMessage = $"Документ ID {SelectedArchivedDocument.DocumentId} восстановлен";
                    LoadDocuments();
                    LoadArchivedDocuments();
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка восстановления: {ex.Message}";
                MessageBox.Show($"Ошибка при восстановлении документа: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void LoadArchivedDocuments()
        {
            try
            {
                var archived = _dbService.GetArchivedDocuments();
                ArchivedDocuments = new ObservableCollection<Document>(archived);
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки архива: {ex.Message}";
            }
        }
        private void RefreshCommands()
        {
            (EditCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (ApproveCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (SendCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (DeleteCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }
        private bool CanArchiveDocument()
        {
            return SelectedDocument != null &&
                  SelectedDocument.Status != "Архивный";
        }

        private void ArchiveDocument()
        {
            try
            {
                var result = MessageBox.Show(
                    $"Архивировать документ '{SelectedDocument.Title}'?",
                    "Подтверждение архивации",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    // Получаем ID текущего пользователя (замените на реальный механизм)
                    int currentUserId = 1;

                    _dbService.ArchiveDocument(SelectedDocument, currentUserId);
                    StatusMessage = $"Документ ID {SelectedDocument.DocumentId} архивирован";
                    LoadDocuments();
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка архивации: {ex.Message}";
                MessageBox.Show($"Ошибка при архивации документа: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ApproveDocument()
        {
            SelectedDocument.Status = "Утвержден";
            _dbService.UpdateDocument(SelectedDocument);
            LoadDocuments();
        }
        private bool CanApproveDocument()
        {
            return SelectedDocument != null &&
                  (SelectedDocument.Status == "Черновик" || SelectedDocument.Status == "На утверждении");
        }
        private void ApproveSelectedDocument()
        {
            try
            {
                SelectedDocument.Status = "Утвержден";
                _dbService.UpdateDocument(SelectedDocument);
                MessageBox.Show($"Документ ID {SelectedDocument.DocumentId} утвержден",
                              "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDocuments();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при утверждении: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private bool CanSendDocument()
        {
            return SelectedDocument != null &&
                  SelectedDocument.Status == "Утвержден" &&
                  SelectedDocument.RecipientDepartmentId.HasValue;
        }
 
        private async void SendDocument()
        {
            try
            {
                bool success = await _commService.SendDocumentToDepartment(SelectedDocument);

                if (success)
                {
                    SelectedDocument.Status = "Отправлен";
                    _dbService.UpdateDocument(SelectedDocument);
                    MessageBox.Show($"Документ ID {SelectedDocument.DocumentId} отправлен",
                                  "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadDocuments();
                }
                else
                {
                    MessageBox.Show("Ошибка при отправке документа",
                                  "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private bool CanDeleteDocument() => SelectedDocument != null;
        private void DeleteDocument()
        {
            try
            {
                var result = MessageBox.Show(
                    $"Вы уверены, что хотите удалить документ '{SelectedDocument.Title}'?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    _dbService.DeleteDocument(SelectedDocument.DocumentId);
                    StatusMessage = $"Документ ID {SelectedDocument.DocumentId} удален";
                    LoadDocuments();
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка удаления: {ex.Message}";
                MessageBox.Show($"Ошибка при удалении документа: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private async void LoadDocuments()
        {
            try
            {
                var docs = await _dbService.GetAllDocumentsAsync();
                Documents.Clear();
                foreach (var doc in docs)
                {
                    Documents.Add(doc);
                }
                StatusMessage = $"Загружено документов: {Documents.Count}";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки: {ex.Message}";
                MessageBox.Show($"Ошибка загрузки документов: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void AddDocument()
        {
            try
            {
                var newDocument = new Document
                {
                    Status = "Черновик",
                    CreatedDate = DateTime.Now
                };

                var editWindow = new DocumentEditWindow(newDocument);

                if (editWindow.ShowDialog() == true)
                {
                    _dbService.AddDocument(editWindow.Document);
                    StatusMessage = "Документ успешно добавлен";
                    LoadDocuments();
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка добавления: {ex.Message}";
                MessageBox.Show($"Ошибка при добавлении документа: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanEditDocument() => SelectedDocument != null;

        private void EditDocument()
        {
            if (SelectedDocument == null) return;

            try
            {
                var editWindow = new DocumentEditWindow(SelectedDocument.Clone());

                if (editWindow.ShowDialog() == true)
                {
                    // Обновляем оригинальный документ
                    SelectedDocument.CopyFrom(editWindow.Document);
                    _dbService.UpdateDocument(SelectedDocument);
                    StatusMessage = $"Документ ID {SelectedDocument.DocumentId} обновлен";
                    LoadDocuments();
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка редактирования: {ex.Message}";
                MessageBox.Show($"Ошибка при редактировании документа: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
