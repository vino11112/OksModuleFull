﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OksModule.Models
{
    public class ArchivedDocument : Document
    {
        public DateTime ArchivedDate { get; set; }
        public int ArchivedBy { get; set; }
    }
}
