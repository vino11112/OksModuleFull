﻿using OksModule.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
namespace OksModule.Services
{
    public class DatabaseService
    {
        private readonly string _connectionString;

        public DatabaseService()
        {
            _connectionString = "Server=DESKTOP-VVN5VCI\\SQLEXPRESS;Database=OksModuleDB;Integrated Security=True;";
        }

        public int SaveDocument(Document document)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = @"INSERT INTO Documents 
                            (DocumentType, Title, Content, Status, CreatedDate, Deadline, AuthorId, RecipientDepartmentId, FilePath)
                            VALUES 
                            (@DocumentType, @Title, @Content, @Status, @CreatedDate, @Deadline, @AuthorId, @RecipientDepartmentId, @FilePath);
                            SELECT SCOPE_IDENTITY();";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DocumentType", document.DocumentType);
                    command.Parameters.AddWithValue("@Title", document.Title);
                    command.Parameters.AddWithValue("@Content", document.Content ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Status", document.Status);
                    command.Parameters.AddWithValue("@CreatedDate", document.CreatedDate);
                    command.Parameters.AddWithValue("@Deadline", document.Deadline ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@AuthorId", document.AuthorId);
                    command.Parameters.AddWithValue("@RecipientDepartmentId", document.RecipientDepartmentId ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@FilePath", document.FilePath ?? (object)DBNull.Value);

                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }
        public async Task<List<Document>> GetAllDocumentsAsync()
        {
            var documents = new List<Document>();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var query = @"SELECT d.*, dep.Name as DepartmentName 
                            FROM Documents d
                            LEFT JOIN Departments dep ON d.RecipientDepartmentId = dep.DepartmentId
                            ORDER BY d.CreatedDate DESC";

                using (var command = new SqlCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        documents.Add(new Document
                        {
                            DocumentId = reader.GetInt32(reader.GetOrdinal("DocumentId")),
                            DocumentType = reader.GetString(reader.GetOrdinal("DocumentType")),
                            Title = reader.GetString(reader.GetOrdinal("Title")),
                            Content = reader.IsDBNull(reader.GetOrdinal("Content")) ? null : reader.GetString(reader.GetOrdinal("Content")),
                            Status = reader.GetString(reader.GetOrdinal("Status")),
                            CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                            Deadline = reader.IsDBNull(reader.GetOrdinal("Deadline")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("Deadline")),
                            AuthorId = reader.GetInt32(reader.GetOrdinal("AuthorId")),
                            RecipientDepartmentId = reader.IsDBNull(reader.GetOrdinal("RecipientDepartmentId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("RecipientDepartmentId")),
                            FilePath = reader.IsDBNull(reader.GetOrdinal("FilePath")) ? null : reader.GetString(reader.GetOrdinal("FilePath")),
                            DepartmentName = reader.IsDBNull(reader.GetOrdinal("DepartmentName")) ? "Не указан" : reader.GetString(reader.GetOrdinal("DepartmentName"))
                        });
                    }
                }
            }

            return documents;
        }

        // Синхронная версия (для обратной совместимости)
        public List<Document> GetAllDocuments()
        {
            return GetAllDocumentsAsync().GetAwaiter().GetResult();
        }

        public async Task<List<Department>> GetAllDepartmentsAsync()
        {
            var departments = new List<Department>();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "SELECT * FROM Departments";

                using (var command = new SqlCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        departments.Add(new Department
                        {
                            DepartmentId = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Code = reader.GetString(2)
                        });
                    }
                }
            }
            return departments;
        }
        public void AddDocument(Document document)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"INSERT INTO Documents 
                    (DocumentType, Title, Content, Status, CreatedDate, Deadline, AuthorId, RecipientDepartmentId, FilePath)
                    VALUES 
                    (@DocumentType, @Title, @Content, @Status, @CreatedDate, @Deadline, @AuthorId, @RecipientDepartmentId, @FilePath)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DocumentType", document.DocumentType ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Title", document.Title ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Content", document.Content ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Status", document.Status ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@CreatedDate", document.CreatedDate);
                    command.Parameters.AddWithValue("@Deadline", document.Deadline ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@AuthorId", document.AuthorId);
                    command.Parameters.AddWithValue("@RecipientDepartmentId", document.RecipientDepartmentId ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@FilePath", document.FilePath ?? (object)DBNull.Value);

                    command.ExecuteNonQuery();
                }
            }
        }
        public void UpdateDocument(Document document)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = @"UPDATE Documents SET 
                     DocumentType = @DocumentType,
                     Title = @Title,
                     Content = @Content,
                     Status = @Status,
                     Deadline = @Deadline,
                     RecipientDepartmentId = @RecipientDepartmentId,
                     FilePath = @FilePath
                     WHERE DocumentId = @DocumentId";

                using (var command = new SqlCommand(query, connection))
                {
                    // Добавляем все параметры явно
                    command.Parameters.AddWithValue("@DocumentId", document.DocumentId);
                    command.Parameters.AddWithValue("@DocumentType", document.DocumentType ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Title", document.Title ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Content", document.Content ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Status", document.Status ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Deadline", document.Deadline ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@RecipientDepartmentId", document.RecipientDepartmentId ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@FilePath", document.FilePath ?? (object)DBNull.Value);

                    command.ExecuteNonQuery();
                }
            }
        }
        public void DeleteDocument(int documentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "DELETE FROM Documents WHERE DocumentId = @DocumentId";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DocumentId", documentId);
                    command.ExecuteNonQuery();
                }
            }
        }
        public void ArchiveDocument(Document document, int archivedByUserId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // 1. Копируем документ в архив
                var archiveQuery = @"INSERT INTO ArchivedDocuments
                          (DocumentId, DocumentType, Title, Content, Status, 
                           CreatedDate, ArchivedBy, OriginalDeadline, 
                           RecipientDepartmentId, FilePath)
                          VALUES 
                          (@DocumentId, @DocumentType, @Title, @Content, @Status,
                           @CreatedDate, @ArchivedBy, @Deadline,
                           @RecipientDepartmentId, @FilePath)";

                // 2. Удаляем из основной таблицы
                var deleteQuery = "DELETE FROM Documents WHERE DocumentId = @DocumentId";

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Архивация
                        using (var archiveCommand = new SqlCommand(archiveQuery, connection, transaction))
                        {
                            archiveCommand.Parameters.AddWithValue("@DocumentId", document.DocumentId);
                            archiveCommand.Parameters.AddWithValue("@DocumentType", document.DocumentType);
                            archiveCommand.Parameters.AddWithValue("@Title", document.Title);
                            archiveCommand.Parameters.AddWithValue("@Content", document.Content ?? (object)DBNull.Value);
                            archiveCommand.Parameters.AddWithValue("@Status", document.Status);
                            archiveCommand.Parameters.AddWithValue("@CreatedDate", document.CreatedDate);
                            archiveCommand.Parameters.AddWithValue("@ArchivedBy", archivedByUserId);
                            archiveCommand.Parameters.AddWithValue("@Deadline", document.Deadline ?? (object)DBNull.Value);
                            archiveCommand.Parameters.AddWithValue("@RecipientDepartmentId", document.RecipientDepartmentId ?? (object)DBNull.Value);
                            archiveCommand.Parameters.AddWithValue("@FilePath", document.FilePath ?? (object)DBNull.Value);

                            archiveCommand.ExecuteNonQuery();
                        }

                        // Удаление
                        using (var deleteCommand = new SqlCommand(deleteQuery, connection, transaction))
                        {
                            deleteCommand.Parameters.AddWithValue("@DocumentId", document.DocumentId);
                            deleteCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
        public List<ArchivedDocument> GetArchivedDocuments()
        {
            var archived = new List<ArchivedDocument>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = @"SELECT * FROM ArchivedDocuments 
                     ORDER BY ArchivedDate DESC";

                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        archived.Add(new ArchivedDocument
                        {
                            DocumentId = reader.GetInt32(reader.GetOrdinal("DocumentId")),
                            DocumentType = reader.GetString(reader.GetOrdinal("DocumentType")),
                            Title = reader.GetString(reader.GetOrdinal("Title")),
                            Content = reader.IsDBNull(reader.GetOrdinal("Content")) ? null : reader.GetString(reader.GetOrdinal("Content")),
                            Status = "Архивный",
                            CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                            ArchivedDate = reader.GetDateTime(reader.GetOrdinal("ArchivedDate")),
                            ArchivedBy = reader.GetInt32(reader.GetOrdinal("ArchivedBy")),
                            Deadline = reader.IsDBNull(reader.GetOrdinal("OriginalDeadline")) ? null : (DateTime?)reader.GetDateTime(reader.GetOrdinal("OriginalDeadline")),
                            RecipientDepartmentId = reader.IsDBNull(reader.GetOrdinal("RecipientDepartmentId")) ? null : (int?)reader.GetInt32(reader.GetOrdinal("RecipientDepartmentId")),
                            FilePath = reader.IsDBNull(reader.GetOrdinal("FilePath")) ? null : reader.GetString(reader.GetOrdinal("FilePath"))
                        });
                    }
                }
            }

            return archived;
        }
        public void RestoreDocument(int documentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // 1. Получаем документ из архива
                        var getQuery = "SELECT * FROM ArchivedDocuments WHERE DocumentId = @DocumentId";
                        Document documentToRestore;

                        using (var getCommand = new SqlCommand(getQuery, connection, transaction))
                        {
                            getCommand.Parameters.AddWithValue("@DocumentId", documentId);

                            using (var reader = getCommand.ExecuteReader())
                            {
                                if (!reader.Read())
                                    throw new Exception("Документ не найден в архиве");

                                documentToRestore = new Document
                                {
                                    DocumentId = reader.GetInt32(reader.GetOrdinal("DocumentId")),
                                    DocumentType = reader.GetString(reader.GetOrdinal("DocumentType")),
                                    Title = reader.GetString(reader.GetOrdinal("Title")),
                                    Content = reader.IsDBNull(reader.GetOrdinal("Content")) ? null : reader.GetString(reader.GetOrdinal("Content")),
                                    Status = "Черновик",
                                    CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                                    Deadline = reader.IsDBNull(reader.GetOrdinal("OriginalDeadline")) ? null : (DateTime?)reader.GetDateTime(reader.GetOrdinal("OriginalDeadline")),
                                    RecipientDepartmentId = reader.IsDBNull(reader.GetOrdinal("RecipientDepartmentId")) ? null : (int?)reader.GetInt32(reader.GetOrdinal("RecipientDepartmentId")),
                                    FilePath = reader.IsDBNull(reader.GetOrdinal("FilePath")) ? null : reader.GetString(reader.GetOrdinal("FilePath"))
                                };
                            }
                        }

                        // 2. Вставляем в основную таблицу
                        var insertQuery = @"INSERT INTO Documents 
                                  (DocumentId, DocumentType, Title, Content, Status, 
                                   CreatedDate, Deadline, RecipientDepartmentId, FilePath)
                                  VALUES 
                                  (@DocumentId, @DocumentType, @Title, @Content, @Status,
                                   @CreatedDate, @Deadline, @RecipientDepartmentId, @FilePath)";

                        using (var insertCommand = new SqlCommand(insertQuery, connection, transaction))
                        {
                            // Добавляем параметры
                            insertCommand.ExecuteNonQuery();
                        }

                        // 3. Удаляем из архива
                        var deleteQuery = "DELETE FROM ArchivedDocuments WHERE DocumentId = @DocumentId";
                        using (var deleteCommand = new SqlCommand(deleteQuery, connection, transaction))
                        {
                            deleteCommand.Parameters.AddWithValue("@DocumentId", documentId);
                            deleteCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
    }
} 
    

