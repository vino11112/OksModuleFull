﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace DocumentReceiver
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<ReceivedDocument> Documents { get; } = new ObservableCollection<ReceivedDocument>();
        private HttpListener _listener;
        private const string ListenUrl = "http://localhost:8080/receive/";

        public MainWindow()
        {
            InitializeComponent();
            DocumentsList.ItemsSource = Documents;
            StartListener();
        }

        private async void StartListener()
        {
            _listener = new HttpListener();
            _listener.Prefixes.Add(ListenUrl);
            _listener.Start();
            StatusText.Text = $"Слушаем на {ListenUrl}";

            while (_listener.IsListening)
            {
                try
                {
                    var context = await _listener.GetContextAsync();
                    ProcessRequest(context);
                }
                catch (Exception ex)
                {
                    StatusText.Text = $"Ошибка: {ex.Message}";
                }
            }
        }

        private async void ProcessRequest(HttpListenerContext context)
        {
            var request = context.Request;
            var response = context.Response;

            try
            {
                if (request.HttpMethod == "POST" && request.Url.AbsolutePath == "/receive/document")
                {
                    using (var reader = new StreamReader(request.InputStream, request.ContentEncoding))
                    {
                        var documentJson = await reader.ReadToEndAsync();
                        var document = System.Text.Json.JsonSerializer.Deserialize<ReceivedDocument>(documentJson);

                        Dispatcher.Invoke(() =>
                        {
                            Documents.Add(document);
                            StatusText.Text = $"Получен документ ID: {document.DocumentId}";
                        });

                        var responseString = "Документ успешно получен";
                        var buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                        response.ContentLength64 = buffer.Length;
                        await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                    }
                }
                else
                {
                    response.StatusCode = 404;
                    var buffer = System.Text.Encoding.UTF8.GetBytes("Not Found");
                    response.ContentLength64 = buffer.Length;
                    await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                }
            }
            finally
            {
                response.Close();
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            _listener?.Stop();
            _listener?.Close();
            base.OnClosed(e);
        }
    }

    public class ReceivedDocument
    {
        public int DocumentId { get; set; }
        public string DocumentType { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public DateTime ReceivedTime { get; set; } = DateTime.Now;
    }
}
